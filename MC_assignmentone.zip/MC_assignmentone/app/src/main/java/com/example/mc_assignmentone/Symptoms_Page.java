package com.example.mc_assignmentone;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Symptoms_Page extends AppCompatActivity
{
    ArrayList<String> symptomsList = new ArrayList<>(Arrays.asList("Nausea",
            "Headache",
            "Diarrhea",
            "Soar Throat",
            "Fever",
            "Muscle Ache",
            "Loss Of Smell Or Taste",
            "Cough",
            "Shortness Of Breath",
            "Feeling Tired"));
    Map<String, Float> symptomMap = new HashMap<String, Float>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symptoms_page);

        Spinner dropdown = findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, symptomsList);
        dropdown.setAdapter(adapter);


        // The stars rating bar widget
        RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar2);

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener()
        {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b)
            {
                int symptomInd = dropdown.getSelectedItemPosition();
                symptomMap.put(symptomsList.get(symptomInd), v);
            }
        });

        // Initialize all the symptom ratings to zero
        for(int i = 0;i < symptomsList.size();i++)
        {
            symptomMap.put(symptomsList.get(i), (float) 0);
        }

        //Update the last 10 columns of the db
        Button btn5 = (Button) findViewById(R.id.button6);

        btn5.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                SQLiteDatabase db = MainActivity.db;

                db.beginTransaction();
                try
                {
                    //perform your database operations here ...
                    db.execSQL( "update symptomstable set nausea='"+symptomMap.get(symptomsList.get(0))+"', headache='"+symptomMap.get(symptomsList.get(1))+"', diarrhea='"+symptomMap.get(symptomsList.get(2))+"', soarthroat='"+symptomMap.get(symptomsList.get(3))+"', fever='"+symptomMap.get(symptomsList.get(4))+"', muscleache='"+symptomMap.get(symptomsList.get(5))+"', lossofsmellortaste='"+symptomMap.get(symptomsList.get(6))+"', cough='"+symptomMap.get(symptomsList.get(7))+"', shortnessofbreath='"+symptomMap.get(symptomsList.get(8))+"', feelingtired='"+symptomMap.get(symptomsList.get(9))+"' where patientID = (SELECT MAX(patientID) FROM symptomstable)" );
                    db.setTransactionSuccessful(); //commit your changes
                }
                catch(SQLiteException e)
                {
                    Toast.makeText(getApplicationContext(), "error:" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.d(  "",  "SQLiteException");
                }
                finally
                {
                    db.endTransaction();
                }
                Toast.makeText(getApplicationContext(), "Database entry added", Toast.LENGTH_SHORT).show();
                Log.d("", "Database entry added");
            }
        });

    }
}