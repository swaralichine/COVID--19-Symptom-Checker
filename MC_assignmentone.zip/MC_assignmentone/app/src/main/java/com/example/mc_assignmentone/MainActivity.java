package com.example.mc_assignmentone;

import static java.lang.Math.abs;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    private Uri fileUri;
    static SQLiteDatabase db;
    private TextView heartRateTextView;
    private TextView breathingRateTextView;
    private boolean ongoingHeartRateProcess = false;
    private boolean ongoingBreathingRateProcess = false;
    long startExecTime;
    private int windows = 9;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button measureHeartRateButton = (Button) findViewById(R.id.button4);

        breathingRateTextView = (TextView) findViewById(R.id.button5) ;

        //Button for new activity page for Symptoms
        Button butt1 = (Button) findViewById(R.id.button);

        butt1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent it = new Intent(view.getContext(),Symptoms_Page.class);
                startActivity(it);
            }
        });

        //Button for creating db
        Button butt2 = (Button) findViewById(R.id.button2);

        butt2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "pressed upload", Toast.LENGTH_SHORT).show();
                try{
                   File f = new File(getExternalFilesDir( null), "swarali.db");
                   Log.d("", f.getPath());
                   db = SQLiteDatabase.openOrCreateDatabase(f.getPath(),  null);
                   db.beginTransaction();
                   try{
                       //Database operations
                       db.execSQL("create table symptomstable ("
                       + "patientID integer PRIMARY KEY autoincrement, "
                       + "heartrate real, " + "respiratoryrate real, " + "nausea real, "
                               + "headache real, " + "diarrhea real, " + "soarthroat real, "
                               + "fever real, " + "muscleache real, " + "lossofsmellortaste real, "
                               + "cough real," + "shortnessofbreath real, " + "feelingtired real);" );
                       db.setTransactionSuccessful(); //commit your changes
                   }
                   catch (SQLiteException e) {
                       Toast.makeText(  MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                       //report problem
                   }
                   finally {
                       db.endTransaction();
                   }
                }catch (SQLException e){

                    Toast.makeText(  MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                }

                //add the data to the db if present
                db.beginTransaction();
                try {
                    //perform your database operations here....
                    db.execSQL("insert into symptomstable(heartrate, respiratoryrate) values ('" +  65+ "','" + 21 + "');");
                    db.setTransactionSuccessful(); //commit your changes
                }
                catch(SQLiteException e) {
                    Toast.makeText(getApplicationContext(), "error:" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.d(  "",  "SQLiteException");
                    //report problem
                }
                finally{
                    db.endTransaction();
            }
                Toast.makeText(getApplicationContext(), "Database entry added", Toast.LENGTH_SHORT).show();
                Log.d("", "Database entry added");
            }
        });

        //Opens recorder on click
        Button butt3 = (Button) findViewById(R.id.button3);

         butt3.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 File videoFile = new File(getExternalFilesDir(null), "heartratevideo.mp4");
                 Uri fileUri = FileProvider.getUriForFile(getApplicationContext(), getApplicationContext().getApplicationContext().getPackageName()+".provider", videoFile);
                 Intent in = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                 in.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 45);

                 in.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
                 startActivityForResult(in,101);
             }
         });

        // Starts Accelerometer service on click
        measureHeartRateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                heartRateTextView = (TextView) findViewById(R.id.button4);


                File videoFile = new File(getExternalFilesDir(null), "heartratevideo.mp4");
                Uri fileUri = FileProvider.getUriForFile(getApplicationContext(), getApplicationContext().getApplicationContext().getPackageName()+".provider", videoFile);

                // Checks if heart rate video exists and if there is an existing heart rate detection process running
                if(ongoingHeartRateProcess == true) {
                    Toast.makeText(MainActivity.this, "Please wait for process to complete before starting a new one!",
                            Toast.LENGTH_SHORT).show();
                } else if (videoFile.exists()) {
                    ongoingHeartRateProcess = true;
                    heartRateTextView.setText("Calculating...");

                    startExecTime = System.currentTimeMillis();
                    System.gc();
                    Intent heartIntent = new Intent(MainActivity.this, HeartRateService.class);
                    startService(heartIntent);

                } else {
                    Toast.makeText(MainActivity.this, "Please record a video first!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button butt5 = (Button) findViewById(R.id.button5);

        butt5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // Checks if there is an existing respiratory rate detection process running
                if(ongoingBreathingRateProcess == true)
                {
                    Toast.makeText(MainActivity.this, "Please wait for process to complete before starting a new one!",
                            Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity.this, "Place the phone on your abdomen \nfor 45s", Toast.LENGTH_LONG).show();
                    ongoingBreathingRateProcess = true;
                    breathingRateTextView.setText("Sensing...");
                    Intent accelIntent = new Intent(MainActivity.this, AccelerometerService.class);
                    startService(accelIntent);

                }
            }
        });
        //Listens for local broadcast containing X values sent by Accelerometer service for calculation
        LocalBroadcastManager.getInstance(MainActivity.this).registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                Bundle b = intent.getExtras();
                BreathingRateDetector runnable = new BreathingRateDetector(b.getIntegerArrayList("accelValuesX"));

                Thread thread = new Thread(runnable);
                thread.start();

                try {
                    thread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }



                breathingRateTextView.setText(runnable.breathingRate + "");

                Toast.makeText(MainActivity.this, "Respiratory rate calculated!", Toast.LENGTH_SHORT).show();
                ongoingBreathingRateProcess = false;
                b.clear();
                System.gc();

            }
        }, new IntentFilter("broadcastingAccelData"));


        //Listens for local broadcast containing average red values of extracted frames sent by Heart rate service for calculation
        LocalBroadcastManager.getInstance(MainActivity.this).registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                Bundle b = intent.getExtras();
                float heartRate = 0;
                int fail = 0;
                //Processes 9 windows of 5 second video snippets separately to calculate heart rate
                for (int i = 0; i < windows; i++) {

                    ArrayList<Integer> heartData = null;
                    heartData = b.getIntegerArrayList("heartData"+i);
                    if(heartData!=null)
                    Log.i("", ""+heartData.size());
                    else Log.i("", "null");
                    //Removes noise from raw average redness frame data
                    ArrayList<Integer> denoisedRedness = denoise(heartData, 5);

                    //Runs peakfinding algorithm on denoised data
                    float zeroCrossings = peakFinding(denoisedRedness);
                    heartRate += zeroCrossings/2;
                    Log.i("log", "heart rate for " + i + ": " + zeroCrossings/2);

                    //Write csv files to memory with raw average redness frames data for reference
                    //String csvFilePath = rootPath + "/heart_rate" + i + ".csv";
                    //saveToCSV(heartData, csvFilePath);

                    //Write csv files to memory with denoised average redness frames data for reference
                    //csvFilePath = rootPath + "/heart_rate_denoised" + i + ".csv";
                    //saveToCSV(denoisedRedness, csvFilePath);
                }

                heartRate = (heartRate*12)/ windows;
                Log.i("log", "Final heart rate: " + heartRate);
                heartRateTextView.setText(heartRate + "");
                ongoingHeartRateProcess = false;
                Toast.makeText(MainActivity.this, "Heart rate calculated!", Toast.LENGTH_SHORT).show();
                System.gc();
                b.clear();

            }
        }, new IntentFilter("broadcastingHeartData"));

    }
    public class BreathingRateDetector implements Runnable{

        public float breathingRate;
        ArrayList<Integer> accelValuesX;

        BreathingRateDetector(ArrayList<Integer> accelValuesX){
            this.accelValuesX = accelValuesX;
        }

        @Override
        public void run() {

//            String csvFilePath = rootPath + "/x_values.csv";
//            saveToCSV(accelValuesX, csvFilePath);

            //Noise reduction from Accelerometer X values
            ArrayList<Integer> accelValuesXDenoised = denoise(accelValuesX, 10);

//            csvFilePath = rootPath + "/x_values_denoised.csv";
//            saveToCSV(accelValuesXDenoised, csvFilePath);

            //Peak detection algorithm running on denoised Accelerometer X values
            int  zeroCrossings = peakFinding(accelValuesXDenoised);
            breathingRate = (zeroCrossings*60)/90;
            Log.i("log", "Respiratory rate" + breathingRate);
        }

    }

    /**
     * Reduces noise such as irregular close peaks from input data using moving average
     * @param data ArrayList data to remove noise from (average redness values/ X values)
     * @param filter Factor to use for doing moving average smoothing
     * @return Data with noise reduced
     */
    public ArrayList<Integer> denoise(ArrayList<Integer> data, int filter){

        ArrayList<Integer> movingAvgArr = new ArrayList<>();
        int movingAvg = 0;

        for(int i=0; i< data.size(); i++){
            movingAvg += data.get(i);
            if(i+1 < filter) {
                continue;
            }
            movingAvgArr.add((movingAvg)/filter);
            movingAvg -= data.get(i+1 - filter);
        }

        return movingAvgArr;

    }

    /**
     * Calculates number of times the signs of slope of the data curve is reversed to get zero crossings
     * @param data ArrayList data to remove noise from (average redness values/ X values)
     * @return Returns number of zero crossings
     */
    public int peakFinding(ArrayList<Integer> data) {

        int diff, prev, slope = 0, zeroCrossings = 0;
        int j = 0;
        prev = data.get(0);

        //Get initial slope
        while(slope == 0 && j + 1 < data.size()){
            diff = data.get(j + 1) - data.get(j);
            if(diff != 0){
                slope = diff/abs(diff);
            }
            j++;
        }

        //Get total number of zero crossings in data curve
        for(int i = 1; i<data.size(); i++) {

            diff = data.get(i) - prev;
            prev = data.get(i);

            if(diff == 0) continue;

            int currSlope = diff/abs(diff);

            if(currSlope == -1* slope){
                slope *= -1;
                zeroCrossings++;
            }
        }

        return zeroCrossings;
    }
}